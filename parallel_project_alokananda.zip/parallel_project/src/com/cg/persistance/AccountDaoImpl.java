package com.cg.persistance;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

import com.cg.bean.CreateAccount;

public class AccountDaoImpl implements IAccountDao{
	CreateAccount cr=new CreateAccount();
		//AccountDaoImpl scd=new AccountDaoImpl();
public void deposit(double acc_no,double password,double amount) throws SQLException, ClassNotFoundException {
	
	Class.forName("oracle.jdbc.driver.OracleDriver");
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	String user="system";
	String pass="Capgemini123";
	Connection con=DriverManager.getConnection(url, user, pass);
	PreparedStatement ps2=con.prepareStatement("Update Account set amount=? where ACC_NO=?");
//ResultSet rs=ps2.executeQuery();
	Scanner sc=new Scanner(System.in);
	double k=amount+sc.nextDouble();
	
	ps2.setDouble(1,k);
	ps2.setDouble(2,acc_no);
	ps2.executeUpdate();
	System.out.println("Amount deposited");
	
	PreparedStatement ps5=con.prepareStatement("insert into print values(?,?,?,?)");
	ps5.setDouble(1,acc_no);
	String details=password+" "+amount+" ";
	ps5.setString(2, details);
	ps5.setDate(3,Date.valueOf(LocalDate.now()));
	String t=LocalTime.now()+"";
	ps5.setString(4,t);
	ps5.executeUpdate();
	con.close();
}

@Override
public void show_Bal() throws SQLException, ClassNotFoundException {
	// TODO Auto-generated method stub
	Class.forName("oracle.jdbc.driver.OracleDriver");
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	String user="system";
	String pass="Capgemini123";
	Connection con=DriverManager.getConnection(url, user, pass);
	PreparedStatement ps1=con.prepareStatement("Select * from Account");
	ResultSet rs=ps1.executeQuery();
	//System.out.println("Enter the account number");
	while(rs.next()) {
		System.out.println(rs.getDouble(1));
		System.out.println(rs.getDouble(2));
		System.out.println(rs.getDouble(3));
		
		
	}
	con.close();
}

@Override
public void withdraw(double acc_no, double password, double amount) throws ClassNotFoundException, SQLException {
	// TODO Auto-generated method stub

	Class.forName("oracle.jdbc.driver.OracleDriver");
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	String user="system";
	String pass="Capgemini123";
	Connection con=DriverManager.getConnection(url, user, pass);
	PreparedStatement ps3=con.prepareStatement("Update Account set amount=? where ACC_NO=?");
	Scanner sc=new Scanner(System.in);
	double j=sc.nextDouble()-amount;
	ps3.setDouble(1,j);
	double k=acc_no;
	ps3.setDouble(2,k);
	//ps3.setDouble(3,password);
	ps3.executeUpdate();
	System.out.println("Amount withdrawn");
	PreparedStatement ps5=con.prepareStatement("insert into print values(?,?,?,?)");
	ps5.setDouble(1,acc_no);
	String details=password+" "+amount+" ";
	ps5.setString(2, details);
	ps5.setDate(3,Date.valueOf(LocalDate.now()));
	String t=LocalTime.now()+"";
	ps5.setString(4,t);
	ps5.executeUpdate();
	con.close();
}

@Override
public void fund_transfer(double acc_no, double password, double transfer_amount, double acc_no2) throws ClassNotFoundException, SQLException {
	// TODO Auto-generated method stub
	  
	 
	Class.forName("oracle.jdbc.driver.OracleDriver");
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	String user="system";
	String pass="Capgemini123";
	Connection con=DriverManager.getConnection(url, user, pass);
	PreparedStatement ps3=con.prepareStatement("Update Account set amount=? where acc_no=?");
	Scanner sc=new Scanner(System.in);
	
	ps3.setDouble(1,sc.nextDouble()-transfer_amount);
	ps3.setDouble(2,acc_no);
	ps3.executeUpdate();
	PreparedStatement ps4=con.prepareStatement("Update Account set amount=? where acc_no=?");
	double l=sc.nextDouble()+transfer_amount;
	ps4.setDouble(1,l);
	ps4.setDouble(2,acc_no2);
	ps4.executeUpdate();
	System.out.println("money transaction done");
	PreparedStatement ps5=con.prepareStatement("insert into print values(?,?,?,?)");
	ps5.setDouble(1,acc_no);
	String details=password+" "+transfer_amount+" ";
	ps5.setString(2, details);
	ps5.setDate(3,Date.valueOf(LocalDate.now()));
	String t=LocalTime.now()+"";
	ps5.setString(4,t);
	ps5.executeUpdate();
	con.close();
}

//@Override
public void createAccount() throws ClassNotFoundException, SQLException {
	// TODO Auto-generated method stub
	Class.forName("oracle.jdbc.driver.OracleDriver");
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	String user="system";
	String pass="Capgemini123";
	Connection con=DriverManager.getConnection(url, user, pass);
	PreparedStatement ps=con.prepareStatement("Create table Account(acc_no number primary key, password number, amount number)");
	ps.executeUpdate();
	
	System.out.println("table created..");
	con.close();
}

@Override
public void InsertQuery( double password, double amount,String name,String email,long mobile) throws SQLException, ClassNotFoundException {
	// TODO Auto-generated method stub
	Class.forName("oracle.jdbc.driver.OracleDriver");
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	String user="system";
	String pass="Capgemini123";
	Connection con=DriverManager.getConnection(url, user, pass);
	PreparedStatement ps=con.prepareStatement("insert into Account values(acc_no_seq.nextval,?,?,?,?,?)");
	
	//ps.setDouble(1,acc_no_seq.nextval);
	
	
	ps.setDouble(1,password);
	ps.setDouble(2,amount);
	ps.setString(3,name);
	ps.setString(4,email);
	ps.setLong(5,mobile);
	ps.executeUpdate();
	System.out.println("row inserted");
	con.close();
}
public void printTransaction(double acc_no) throws ClassNotFoundException, SQLException {
	Class.forName("oracle.jdbc.driver.OracleDriver");
	String url="jdbc:oracle:thin:@localhost:1521:XE";
	String user="system";
	String pass="Capgemini123";
	Connection con=DriverManager.getConnection(url, user, pass);
	//PreparedStatement ps=con.prepareStatement("Create table print(acc_no number,password number,date date,type_of_transaction varchar(50))");
	//ps.executeUpdate();
	//System.out.println("table created..");
	PreparedStatement ps1=con.prepareStatement("select * from print where acc_no=?");
	ps1.setDouble(1,acc_no);
	ResultSet rs=ps1.executeQuery();
	while(rs.next()) {
		System.out.println(rs.getDouble(1)+" ");
		System.out.println(rs.getString(2)+" ");
		System.out.println(rs.getDate(3)+" ");
		System.out.println(rs.getString(4));
	
	
	
	}
	con.close();

}
}
