package com.cg.service;

import java.sql.SQLException;

public interface IAccountService {
	void show_Bal() throws SQLException, ClassNotFoundException;
	public void InsertQuery(double password, double amount,String name,String email,long mobile) throws SQLException, ClassNotFoundException;
	void deposit(double acc_no,double password,double amount) throws SQLException, ClassNotFoundException;
	void withdraw(double acc_no,double password,double amount) throws ClassNotFoundException, SQLException;
	void fund_transfer(double acc_no,double password,double transfer_amount,double acc_no2) throws ClassNotFoundException, SQLException;
	void createAccount() throws ClassNotFoundException, SQLException;
	public void printTransaction(double acc_no) throws ClassNotFoundException, SQLException;
}
