package com.cg.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.bean.CreateAccount;
import com.cg.service.AccountServiceImpl;
import com.cg.service.IAccountService;

public class TestCreateAccount {


public static void main(String args[]) throws ClassNotFoundException, SQLException {
	IAccountService as=new AccountServiceImpl();
	CreateAccount cr=new CreateAccount();
	
	
	while(true) {
		System.out.println("Choose any option");
		System.out.println("1.Create Account\n2.Insert Balance\n3.show\n4.Deposit\n5.Withdraw\n6.Fund Transaction\n7.Print transaction");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		switch(n) {
		case 1:
			
		as.createAccount();
			break;
		case 2:
			
		/*	System.out.println("Enter the account number");
			double acc_number11=sc.nextDouble();*/
			System.out.println("Enter the password");
			double password12=sc.nextDouble();
			
			 System.out.println("Enter the amount");
			 double amount=sc.nextDouble();
			 System.out.println("Enter the name");
			 String name=sc.next();
			 
			 System.out.println("Enter the mail");
			 String email=sc.next();
			
				String regEx1="[a-zA-Z0-9]+[.]*[a-zA-Z0-9]+[@][a-zA-Z0-9]+([.][a-zA-Z]{2,})+";
						 while(!email.matches(regEx1)) {
							 System.out.println("not valid\nEnter once again!");
							 email=sc.next();
							 
						 }
						 System.out.println("Enter the mobile number");
						long mobile=sc.nextLong();
						String regEx="(91/0)?[6-9][0-9]{9}";
						String se=mobile+"";
						 while(!se.matches(regEx)) {
							 
							 System.out.println("not valid\nEnter once again");
							 mobile=sc.nextLong();
							 
						 }		
							
						 as.InsertQuery( password12, amount, name, email,mobile);
		case 3:as.show_Bal();
		break;
		case 4:
			System.out.println("Enter the account number");
			double acc_number13=sc.nextDouble();
			System.out.println("Enter the password");
			double password13=sc.nextDouble();
			System.out.println("Enter the amount to deposit");
			double deposit=sc.nextDouble();
			as.deposit(acc_number13, password13, deposit);
			break;
		case 5:System.out.println("Enter the account number");
		double acc_number14=sc.nextDouble();
		System.out.println("Enter the password");
		double password14=sc.nextDouble();
		System.out.println("Enter the amount to withdrawn");
		double withdraw=sc.nextDouble();
		as.withdraw(acc_number14, password14, withdraw);
		break;
		case 6:System.out.println("Enter the account number from where you want to execute transaction");
		double acc_no16=sc.nextDouble();
		System.out.println("Enter the password of this account");
		double password16=sc.nextDouble();
		System.out.println("Enter the amount to be transacted");
		double transfer_amount16=sc.nextDouble();
		System.out.println("Enter the account number where the transacted money will go?");
		double acc_no_2=sc.nextDouble();
		as.fund_transfer(acc_no16,password16, transfer_amount16, acc_no_2);
		break;
		case 7:System.out.println("print transaction\nEnter account number");
		double acc_no=sc.nextDouble();
		as.printTransaction(acc_no);
		
		}
		
	}
}

}