package com.cg.service;

import java.sql.SQLException;

import com.cg.persistance.AccountDaoImpl;
import com.cg.persistance.IAccountDao;

public class AccountServiceImpl implements IAccountService{
IAccountDao io=new AccountDaoImpl();

@Override
public void show_Bal() throws SQLException, ClassNotFoundException {
	// TODO Auto-generated method stub
	io.show_Bal();
}

@Override
public void deposit(double acc_no, double password, double amount) throws SQLException, ClassNotFoundException {
	// TODO Auto-generated method stub
	io.deposit(acc_no, password, amount);
}

@Override
public void withdraw(double acc_no, double password, double amount) throws ClassNotFoundException, SQLException {
	// TODO Auto-generated method stub
	io.withdraw(acc_no, password, amount);
}

@Override
public void fund_transfer(double acc_no, double password, double transfer_amount, double acc_no2)
		throws ClassNotFoundException, SQLException {
	// TODO Auto-generated method stub
	io.fund_transfer(acc_no, password, transfer_amount, acc_no2);
}

public void createAccount() throws ClassNotFoundException, SQLException {
	// TODO Auto-generated method stub
	io.createAccount();
}

@Override
public void InsertQuery( double password, double amount,String name,String email,long mobile) throws SQLException, ClassNotFoundException {
	// TODO Auto-generated method stub
	io.InsertQuery(password, amount,name,email,mobile);
}

@Override
public void printTransaction(double acc_no) throws ClassNotFoundException, SQLException {
	// TODO Auto-generated method stub
	io.printTransaction(acc_no);
}






}
