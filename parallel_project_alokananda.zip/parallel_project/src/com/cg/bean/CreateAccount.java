package com.cg.bean;

public class CreateAccount {
double acc_no;
double password;
double amount;
double acc_no2;
double transfer_amount;
String email;
String name;


@Override
public String toString() {
	return "CreateAccount [acc_no=" + acc_no + ", password=" + password + ", amount=" + amount + ", acc_no2=" + acc_no2
			+ ", transfer_amount=" + transfer_amount + ", getTransfer_amount()=" + getTransfer_amount()
			+ ", getPassword()=" + getPassword() + ", getAmount()=" + getAmount() + ", getAcc_no2()=" + getAcc_no2()
			+ ", getAcc_no()=" + getAcc_no() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
			+ ", toString()=" + super.toString() + "]";
}

public double getTransfer_amount() {
	return transfer_amount;
}

public void setTransfer_amount(double transfer_amount) {
	this.transfer_amount = transfer_amount;
}

public double getPassword() {
	return password;
}

public void setPassword(double password) {
	this.password = password;
}

public double getAmount() {
	return amount;
}

public void setAmount(double amount) {
	this.amount = amount;
}

public double getAcc_no2() {
	return acc_no2;
}

public void setAcc_no2(double acc_no2) {
	this.acc_no2 = acc_no2;
}

public double getAcc_no() {
	return acc_no;
}

public void setAcc_no(double acc_no) {
	this.acc_no = acc_no;
}

}
